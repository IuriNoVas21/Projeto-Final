import express from "express";
import { router } from "./routes.js"; // Importa o roteador das rotas configuradas
import cors from "cors";

const app = express();
app.use(express.json()); // Middleware para interpretar JSON no corpo das requisições

// Configuração de CORS para permitir comunicações entre diferentes origens
app.use(cors({
  origin: "*", // Permite qualquer origem. Substitua por uma origem específica, se necessário.
  methods: "GET,POST,PUT,DELETE", // Métodos HTTP permitidos
  allowedHeaders: "*" // Cabeçalhos HTTP permitidos
}));

// Middleware adicional para definir cabeçalhos de resposta manualmente
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // Permite acesso de qualquer origem
  res.header("Access-Control-Allow-Headers", "*"); // Permite qualquer cabeçalho
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE"); // Métodos suportados
  next(); // Passa para o próximo middleware ou rota
});

// Configuração do roteador importado para gerenciar as rotas da aplicação
app.use(router);

// Configuração do servidor para escutar na porta 8000
app.listen(8000, () => {
  console.log("8000 Server is running"); // Mensagem indicando que o servidor está ativo
});
