import { Router } from "express";
import UserController from "./controllers/UserController.js"; // Controlador para gerir utilizadores
import SessionController from "./controllers/SessionController.js"; // Controlador para sessões (login)
import ImobiController from "./controllers/ImobiController.js"; // Controlador para imóveis
import auth from "./middlewares/auth.js"; // Middleware de autenticação

import multer from "multer"; // Middleware para upload de ficheiros
import uploadConfig from "./middlewares/upload.js"; // Configuração para upload de ficheiros

const upload = multer(uploadConfig); // Instância do multer com a configuração fornecida

const router = Router();

// Rotas para gestão de utilizadores
router.post("/createusers", UserController.createUser); // Criação de um novo utilizador
router.get("/listusers", auth, UserController.findAllUser); // Listagem de utilizadores (requer autenticação)

// Rota para gestão de sessões
router.post("/session", SessionController.createSession); // Criação de uma nova sessão (login)

// Rotas para gestão de imóveis
router.post('/createimobi', upload.single("thumb"), ImobiController.createImobi); 
// Criação de um imóvel com upload de imagem (campo "thumb")

router.get('/listimobi', ImobiController.findAllImobi); // Listagem de todos os imóveis
router.get('/listimobi/:id', ImobiController.findImobi); // Busca de um imóvel específico pelo ID

export { router }; // Exporta o roteador para uso no servidor principal
