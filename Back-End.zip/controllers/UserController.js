import { PrismaClient } from "@prisma/client";
import { hash } from "bcrypt";
const prisma = new PrismaClient();

export default {
  // Função para criar um novo utilizador
  async createUser(request, response) {
    const { name, email, password } = request.body; // Obtém o nome, email e palavra-passe do corpo da requisição

    try {
      // Verifica se o utilizador já existe pelo email
      let user = await prisma.user.findUnique({ where: { email } });

      if (user) {
        return response.json({
          error: true,
          message: "Erro: Utilizador já existe!", // Mensagem de erro caso o utilizador já esteja registado
        });
      }

      // Faz o hash da palavra-passe antes de armazenar no sistema
      const HashPassword = await hash(password, 8);

      // Cria um novo utilizador com os dados fornecidos
      user = await prisma.user.create({
        data: {
          name,
          email,
          password: HashPassword, // Armazena a palavra-passe encriptada
        },
      });

      return response.json({
        error: false,
        message: "Sucesso: Utilizador registrado com sucesso!", // Mensagem de sucesso
        user, // Dados do utilizador registado
      });
    } catch (error) {
      return response.json({ message: error.message }); // Retorna mensagem de erro caso ocorra um problema
    }
  },

  // Função para listar todos os utilizadores
  async findAllUser(request, response) {
    try {
      const user = await prisma.user.findMany(); // Obtém todos os utilizadores da base de dados
      return response.json(user); // Retorna a lista de utilizadores
    } catch (error) {
      return response.json({ message: error.message }); // Retorna mensagem de erro caso ocorra um problema
    }
  },

  // Função para encontrar um utilizador específico
  async findUser(request, response) {
    try {
      const { userId } = request.params; // Obtém o ID do utilizador dos parâmetros da requisição

      const user = await prisma.user.findUnique({
        where: { id: Number(userId) }, // Busca o utilizador pelo ID
      });

      delete user.password; // Remove a palavra-passe dos dados antes de enviar a resposta

      return response.json(user); // Retorna os dados do utilizador encontrado
    } catch (error) {
      return response.json({ message: error.message }); // Retorna mensagem de erro caso ocorra um problema
    }
  },
};
