import React, { Fragment } from 'react';
import { Container, Description, Img, Itens} from './styles'; // Importação dos estilos personalizados
import { FaArrowRight, FaMapMarkerAlt } from "react-icons/fa"; // Importação de ícones para mapa e seta
import { Link } from 'react-router-dom'; // Link para navegação entre páginas

const Card = () => {
  return (
    <Container>
        {/* Imagem do imóvel */}
        <Img>
          <img 
            src="https://images.unsplash.com/photo-1507149833265-60c372daea22?q=80&w=2076&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" 
            alt="Imagem do imóvel" 
          />
        </Img>
        
        {/* Descrição do imóvel */}
        <Description>
            <h4>Apartamento</h4> {/* Título do tipo de imóvel */}
            
            {/* Informações sobre o imóvel (localização e preço) */}
            <Itens>
                <span><FaMapMarkerAlt />Lisboa Central</span> {/* Ícone de localização e nome da cidade */}
                <span>1000 €/mês</span> {/* Preço do aluguel */}
            </Itens>
            
            {/* Link para a página de detalhes do imóvel */}
            <Link to="/imovel">Detalhes<FaArrowRight /></Link> {/* Navega para a página de detalhes */}
        </Description>
    </Container>
  );
};

export default Card; // Exporta o componente para uso em outras partes da aplicação
