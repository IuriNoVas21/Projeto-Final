import React, { Fragment } from 'react';
import { FaFacebook, FaInstagram, FaWhatsapp } from "react-icons/fa"; // Importação dos ícones sociais
import { Container, Copy, Item } from './styles'; // Estilos personalizados para o rodapé
import LogoImg from '../../assets/logo.png'; // Importação do logo da empresa

const Footer = () => {
  return (
    <Fragment>
      {/* Contêiner principal do rodapé */}
      <Container>
        {/* Item de logo e descrição */}
        <Item>
          <img src={LogoImg} alt="Logo" /> {/* Exibe o logo da empresa */}
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
          </p>
          
          {/* Navegação com ícones sociais */}
          <nav>
            <li><span><FaFacebook size={32}/></span></li> {/* Ícone do Facebook */}
            <li><span><FaInstagram size={32}/></span></li> {/* Ícone do Instagram */}
            <li><span><FaWhatsapp size={32}/></span></li> {/* Ícone do WhatsApp */}
          </nav>
        </Item>
        
        {/* Seção de serviços oferecidos */}
        <Item>
          <h3>Our Services</h3> {/* Título da seção */}
          <ul>
            <li><span>Comprar</span></li> {/* Serviço de compra */}
            <li><span>Alugar</span></li> {/* Serviço de aluguel */}
            <li><span>Vender</span></li> {/* Serviço de venda */}
          </ul>
        </Item>
        
        {/* Repetição das seções de serviços, pode ser ajustado conforme necessário */}
        <Item>
          <h3>Our Services</h3>
          <ul>
            <li><span>Comprar</span></li>
            <li><span>Alugar</span></li>
            <li><span>Vender</span></li>
          </ul>
        </Item>
        <Item>
          <h3>Our Services</h3>
          <ul>
            <li><span>Comprar</span></li>
            <li><span>Alugar</span></li>
            <li><span>Vender</span></li>
          </ul>
        </Item>
      </Container>

      {/* Copyright e links de políticas */}
      <Copy>
        <p>Copyright © United Nations 2024</p> {/* Texto de copyright */}
        <ul>
          <li><span>Termos de Uso</span></li> {/* Link para os termos de uso */}
          <li><span>Politica de Privacidade</span></li> {/* Link para a política de privacidade */}
          <li><span>Politica de Cookies</span></li> {/* Link para a política de cookies */}
        </ul>
      </Copy>
    </Fragment>
  );
};

export default Footer; // Exporta o componente Footer para uso em outras partes da aplicação
