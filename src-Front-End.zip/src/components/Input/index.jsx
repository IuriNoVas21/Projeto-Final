import React, { Fragment } from 'react'; // Importação do React e Fragment (não utilizado neste código, mas pode ser útil para componentes maiores)
import { Container } from './styles'; // Importação do componente de estilo para o Input

// Componente funcional Input
const Input = (props) => {
  return (
    <Container {...props}/> // O Container é o componente estilizado que recebe todas as props passadas para o Input
  );
};

export default Input; // Exportação do componente Input para ser usado em outras partes da aplicação
