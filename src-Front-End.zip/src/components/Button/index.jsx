import React from 'react';
import { Container } from './styles'; // Importação de estilos personalizados para o botão

// Componente Button que aceita "props" e "children"
const Button = ({ props, children }) => {
  return (
    // Usa o componente Container para estilizar o botão e aplica as propriedades passadas
    <Container {...props}>
        {children} {/* Renderiza o conteúdo passado como filho do botão */}
    </Container>
  );
};

export default Button; // Exporta o componente para uso em outras partes da aplicação
