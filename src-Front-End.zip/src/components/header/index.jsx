import React from "react"; // Importação do React
import { Link } from "react-router-dom"; // Importação do Link do react-router-dom para navegação
import LogoImg from "../../assets/logo.png"; // Imagem do logo da empresa
import { Container, Logo, Menu } from "./styles"; // Estilos personalizados para o cabeçalho

const Header = () => {
  return (
    <Container> {/* Contêiner principal que envolve todo o cabeçalho */}
      <Logo> {/* Contêiner para o logo */}
        <Link to="/"> {/* Link para a página inicial */}
          <img src={LogoImg} alt="" /> {/* Imagem do logo da empresa */}
        </Link>
      </Logo>

      <Menu> {/* Contêiner do menu de navegação */}
        <ul> {/* Lista de itens do menu */}
          <li>
            <Link to="/login"> {/* Link para a página de login/registro */}
              <span>Registro/Login</span> {/* Texto exibido no item do menu */}
            </Link>
          </li>
        </ul>
      </Menu>
    </Container>
  );
};

export default Header; // Exportação do componente Header para uso em outras partes da aplicação
