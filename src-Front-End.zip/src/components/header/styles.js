import styled from 'styled-components';

export const Container = styled.div`
    padding: 25px 150px;
    height: 96px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid rgba(0, 0, 0, 0);
    background-color: var(--white); /* Corrigido */
`;

export const Logo = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    img {
        width: 300px;
    }
`;

export const HeaderContainer = styled.header`
    position: relative;
    z-index: 3; /* Adicionar um z-index maior que o do Overlay */
    background-color: #fff;
    padding: 20px;
    /* Outros estilos do Header */
`;

export const Menu = styled.div`
    ul {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    li {
        border: 1px solid var(--gray);
        border-radius: 10px;
        padding: 10px;
        span {
            font-size: 1.2rem;
            font-weight: 300;
        }
        &:hover {
            background-color: var(--gray);
            cursor: pointer;
        }
    }
`;
