import React from 'react'; // Importação do React
import { Container, Text } from './styles'; // Importação dos componentes estilizados Container e Text

// Componente funcional TopBanner
const TopBanner = () => {
  return (
    <Container> {/* Componente estilizado que envolve o conteúdo do banner */}
      <Text> {/* Componente estilizado que contém o texto do banner */}
        <h2>Apartamentos</h2> {/* Título do banner */}
        <p>Milhares de pessoas ja compraram o seu apartamento de sonho encontre o seu connosco!</p> {/* Descrição do banner */}
      </Text>
    </Container>
  );
};

export default TopBanner; // Exportação do componente TopBanner para ser utilizado em outras partes da aplicação
