import React from "react";
import { Container, Text } from "./styles"; // Importação de estilos personalizados

const Banner = () => {
  return (
    <Container>
      {/* Secção de texto do banner */}
      <Text>
        {/* Título principal do banner */}
        <h2>Discover The Beauty of Your Next Flat</h2>
        {/* Texto descritivo do banner */}
        <p>
          Thousands of people have their flats up for grabs. Don't miss your chance to grab your own house today.
        </p>
        {/* Chamada para ação (CTA) */}
        <span>Cadastre seu anúncio</span>
      </Text>
    </Container>
  );
};

export default Banner; // Exporta o componente para uso em outras partes da aplicação
