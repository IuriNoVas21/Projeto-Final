import React, { Children, Fragment } from 'react'; // Importação do React e, embora não utilizado, Fragment (útil para componentes maiores) e Children (não utilizado neste código)
import { Container } from './styles'; // Importação do componente de estilo para o TextArea

// Componente funcional TextArea
const TextArea = (props) => {
  return (
    <Container {...props} /> // O Container é o componente estilizado que recebe todas as props passadas para o TextArea
  );
};

export default TextArea; // Exportação do componente TextArea para ser utilizado em outras partes da aplicação
