import React, { Fragment, useState } from "react";
import { Container, ContainerForm, Form, Label } from "./styles"; // Importação de estilos personalizados
import Input from "../../components/Input"; // Componente reutilizável para entrada de texto
import axios from "axios"; // Biblioteca para requisições HTTP
import Button from "../../components/Button"; // Componente reutilizável de botão
import Api from "../../services/Api"; // Instância de API configurada
import { toast } from "react-toastify"; // Biblioteca para notificações

const Registro = () => {
  // Estado para armazenar os dados do formulário
  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
  });

  // Função para atualizar o estado com os valores dos campos
  const InputValue = (e) =>
    setData({
      ...data,
      [e.target.name]: e.target.value, // Atualiza o estado com base no nome do campo
    });

  // Função para lidar com o envio do formulário
  const handleSubmit = (e) => {
    e.preventDefault(); // Evita o recarregamento da página
    Api.post("/createusers", data) // Envia os dados do formulário para a API
      .then((response) => {
        // Verifica se houve erro na resposta da API
        if (!response.data.error == true) {
          toast(response.data.message); // Exibe uma mensagem de sucesso
        } else {
          toast(response.data.message); // Exibe uma mensagem de erro
        }
      })
      .catch(() => console.log("Erro: Erro no sistema")); // Lida com erros na requisição
  };

  return (
    <Container>
      <h2>Crie a sua Conta</h2> {/* Título da página */}
      <p>Registre-se para acessar a plataforma</p> {/* Subtítulo com instruções */}
      <ContainerForm>
        <Form onSubmit={handleSubmit} autoComplete="off">
          {/* Campo para o nome */}
          <Label>Nome</Label>
          <Input
            type="text"
            name="name"
            placeholder="Informe o seu Nome"
            onChange={InputValue} // Atualiza o estado quando o valor muda
          />
          {/* Campo para o email */}
          <Label>Email</Label>
          <Input
            type="text"
            name="email"
            placeholder="Informe o seu Email"
            onChange={InputValue}
          />
          {/* Campo para a senha */}
          <Label>Senha</Label>
          <Input
            type="text"
            name="password"
            placeholder="Informe a sua Senha"
            onChange={InputValue}
          />
          {/* Botão para submeter o formulário */}
          <Button>Fazer Registro</Button>
        </Form>
      </ContainerForm>
    </Container>
  );
};

export default Registro; // Exporta o componente para uso em outras partes da aplicação
