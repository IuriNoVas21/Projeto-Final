import React, { Fragment, useState } from "react";
import { Container, ContainerForm, Form, Label } from "./styles"; // Estilos personalizados para a página de login
import Input from "../../components/Input"; // Componente de entrada de texto reutilizável
import Button from "../../components/Button"; // Componente de botão reutilizável
import { AppAuth } from "../../context/AppAuth"; // Contexto de autenticação para gerir o estado do login

const Login = () => {
  const auth = AppAuth(); // Obtém as funções de autenticação do contexto
  const [email, setEmail] = useState(); // Estado para armazenar o email
  const [password, setPassword] = useState(); // Estado para armazenar a senha

  // Função para lidar com o envio do formulário de login
  const handleLogin = async (e) => {
    e.preventDefault(); // Evita o recarregamento da página
    await auth.authenticate(email, password); // Chama a função de autenticação passando as credenciais
  };

  return (
    <Container>
      <h2>Acesse sua conta</h2> {/* Título da página */}
      <p>Entre com o seu email e senha</p> {/* Subtítulo com instruções */}
      <ContainerForm>
        <Form onSubmit={handleLogin}>
          {/* Campo para o email */}
          <Label>Email</Label>
          <Input
            type="text"
            name="email"
            placeholder="Informe o seu Email"
            onChange={(e) => setEmail(e.target.value)} // Atualiza o estado do email
          />
          {/* Campo para a senha */}
          <Label>Senha</Label>
          <Input
            type="text"
            name="password"
            placeholder="Informe a sua Senha"
            onChange={(e) => setPassword(e.target.value)} // Atualiza o estado da senha
          />
          {/* Botão para submeter o formulário */}
          <Button type="submit">Fazer Login</Button>
        </Form>
      </ContainerForm>
    </Container>
  );
};

export default Login; // Exporta o componente para uso em outras partes da aplicação
