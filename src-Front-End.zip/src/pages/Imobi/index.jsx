import React, { Fragment } from "react";
import Input from "../../components/Input"; // Componente de campo de entrada de texto
import TextArea from '../../components/TextArea'; // Componente de área de texto
import {
  Container,
  Description,
  Left,
  Profile,
  ProfileContact,
  ProfileDescription,
  ProfileFormContact,
  ProfileImg,
  Right,
  Thumb,
} from "./styles"; // Importação de estilos personalizados
import TopBanner from "../../components/TopBanner"; // Componente de banner no topo
import Button from "../../components/Button"; // Componente de botão

const Imobi = () => {
  return (
    <Fragment> {/* Fragmento para envolver os elementos sem adicionar um nó extra */}
      <TopBanner /> {/* Banner no topo da página */}
      <Container>
        {/* Secção esquerda: detalhes do imóvel */}
        <Left>
          <Thumb>
            <img
              src="https://images.unsplash.com/photo-1507149833265-60c372daea22?q=80&w=2076&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="" // Imagem do imóvel
            />
          </Thumb>
          <Description>
            <h2>Apartamento / Alugar</h2> {/* Título do imóvel */}
            <p>
              {/* Descrição do imóvel */}
              orem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur. Excepteur sint
            </p>
          </Description>
        </Left>
        
        {/* Secção direita: informações do vendedor e formulário de contacto */}
        <Right>
          {/* Perfil do vendedor */}
          <Profile>
            <ProfileImg>
              <img
                src="https://images.unsplash.com/placeholder-avatars/extra-large.jpg?dpr=1&auto=format&fit=crop&w=150&h=150&q=60&crop=faces&bg=fff"
                alt="" // Imagem do vendedor
              />
            </ProfileImg>
            <ProfileDescription>
              <h3>Leana Raposo</h3> {/* Nome do vendedor */}
              <p>Descrição do utilizador</p> {/* Breve descrição */}
            </ProfileDescription>
          </Profile>

          {/* Informações de contacto do vendedor */}
          <ProfileContact>
            <h3>Informações de Contacto:</h3>
            <p>(11) 111-111-1111</p> {/* Número de telefone */}
            <p>teste@teste.com</p> {/* Email de contacto */}
          </ProfileContact>

          {/* Formulário de contacto */}
          <ProfileFormContact>
            <h3>Contactar o Vendedor</h3>
            <form>
              <Input type="text" placeholder="Nome:" /> {/* Campo para nome */}
              <Input type="text" placeholder="Email:" /> {/* Campo para email */}
              <TextArea type="text" placeholder="Mensagem:" /> {/* Área para mensagem */}
              <Button>Enviar Mensagem</Button> {/* Botão para submeter */}
            </form>
          </ProfileFormContact>
        </Right>
      </Container>
    </Fragment>
  );
};

export default Imobi; // Exporta o componente para ser utilizado em outras partes da aplicação
