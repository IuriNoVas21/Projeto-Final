import React from "react";


const Perfil = () => {
    return(
        <h2>Perfil do Utilizador</h2>
    )       
}

export default Perfil;